//this is tab menus area//
$( function() {
   $( "#main,#m2,#m3,#m4,#m5,#m6,#m7,#m8,#m9" ).tabs();
 } );

//this is table position fixed area//
$(document).ready(function(){
  var counter=0;
  $(".MyTable th").each(function(){
    var width=$('.MyTable tr:last td:eq('+ counter +')').width();
    $(".NewHeader tr").append(this);
    this.width= width;
    counter++;
  });
});

//this is image display area after select//
function readURL(input) {
       if (input.files && input.files[0]) {
           var reader = new FileReader();

           reader.onload = function (e) {
               $('.blah')
                   .attr('src', e.target.result)
                   .width(100)
                   .height(110);
           };

           reader.readAsDataURL(input.files[0]);
       }
   }
   //this is modal
     var modal=document.getElementById('modal-wrapper1,modal-wrapper2,modal-wrapper3,modal-wrapper4,modal-wrapper5,modal-wrapper6,modal-wrapper7');
       window.onclick= function(event){
       if(event.target==modal){
       modal.style.display="none";
       }
       }


//this is for draggable//

       $( function() {
  $( "#form_div" ).draggable();
} );

//this is for menubars active color

$(document).ready(function(){
  $('ul li a').click(function(){
    $('li a').removeClass("active");
    $(this).addClass("active");
});
});
