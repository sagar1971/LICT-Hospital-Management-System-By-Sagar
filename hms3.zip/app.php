<?php
require('session.php');
?>
<?php
require('db.php');
?>


<?php
if(isset($_POST['sub'])){
  $name=$_POST['apname'];
  $add=$_POST['apadd'];
  $co=$_POST['apcon'];
  $spe=$_POST['apspc'];
  $age=$_POST['apage'];
  $apdoc=$_POST['apdoc'];
  $gen=$_POST['apgen'];
  $smp=$_POST['smp'];
  $img=$_POST['file'];
  $visibility=1;
  $fee=500;

  $con=mysqli_connect($ip,$user,$pass,$dbname);
      if(!mysqli_connect_errno()){
          echo "";
  $query="INSERT INTO appointement(`name`,`address`,`contact`,`specialist`,`symptom`,`gender`,`apdoc`,`age`,`visible`,`img`,`fees`)
              VALUES('{$name}','{$add}','{$co}','{$spe}','{$smp}','{$gen}','{$apdoc}','{$age}','{$visibility}','{$image}','{$fee}')";

              if(mysqli_query($con,$query)){
                echo "<script>alert('Your Data Successfully Inserted');</script>";
              }
               else{
                echo "Failed";
              }
              if (move_uploaded_file($_FILES['img']['tmp_name'], $target)) {
                $msg = "Image uploaded successfully";
              }else{
                $msg = "Failed to upload image";
              }
            }else{
              die("ERROR:".mysqli_connect_error());
            }
          }
  mysqli_close($con);
  header("location:allinone.php");
 ?>
