<?php
require('session.php');
?>
<?php
require('db.php');
?>



<?php

       $connection_update = mysqli_connect($ip, $user, $pass, $dbname);
       $id = '';
       if( isset( $_GET['lview'])) {
         $id = $_GET['lview'];
       }
       if (!mysqli_connect_errno()){
         $query = "SELECT * FROM lab WHERE `id`='{$id}'";
         $result = mysqli_query($connection_update,$query);
         if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
           $a=$row['name'];
           $b=$row['address'];
           $c=$row['contact'];
           $d=$row['img'];



         }
       }else{
         echo "ERROR : Database connection failed !"."<br>";
       }
       mysqli_close($connection_update);

       //Update the data and Save it into the MySQL database;

       ?>
       <html>
       <head>
         <link rel="shortcut icon" type="image/x-icon" href="img/icon.png">
         <meta name="viewport" content="width=device-width, initial-scale=1">
         <script src="js/jquery-3.1.0.min.js"></script>
         <script src="js/jquery-ui.js"></script>
         <script src="js/all.js"></script>
         <script type="text/javascript">
           function printLayer(layer)
           {
             var generator=window.open(",'name,");
             var layetext = document.getElementById(layer);
             generator.document.write(layetext.innerHTML.replace("Print Me"));

             generator.document.close();
             generator.print();
             generator.close();
           }
         </script>
         <style>
         h3{
           margin-left: 20px;
         }
         h4{
           text-align: center;
         }
           table{
             font-size: 12px;
             margin-left: 100px;
           }
           div{
             width: 40%;
             height: 600px;
             margin: auto;
             border: 8px solid #56D4E3;
             background-color: white;
             position: relative;

           }
           #des{
             height: 650px;
             width: 80%;
             border: none;
             font-size: 24px;
             font-family: French Script MT;
             margin: auto;
             padding-left: 20px;
             padding-top: 40px;
             font-weight: bolder;
           }
           body{
             background-image: url(img/back.PNG);
             background-repeat: no-repeat;
             background-size: 100%;
           }
           img{
             float: left;
             margin-left: 10px;
             width: 70px;
             height: 90px;
           }
           .img{
             float: right;
             height: 100px;
             width: 80px;
             padding-left: 40px;
             padding-top: 20px;

           }
           .p{
             float: right;
             margin-top: 34px;
             margin-right: 20px;
           }
           .sign{
             margin-top: 550px;
             font-family: sans-serif;
             font-size: 14px;
             margin-left: -30px;
           }
           .pr{
             color:blue;
             font-family: sans-serif;
             font-size: 14px;
             float: right;
             margin-right: 10px;
             margin-top: 270px;
           }
           span{
             float: right;
             margin-top: -8px;
             font-size: 24px;
             font-weight: bolder;

           }
           table{
             margin: auto;
             font-size: 18px;
             margin-top: 80px;
           }
         </style>
       </head>
       <body>
       <div id="div-id-name">
         <a href="allinone.php">  <span  class="close">
  &times;
 </span></a>
         <img src="img/h1.png" class="img">
         <h3>Lict Hospital Management Project</h3>

         <h4>Doctor Details</h4>

         <img src="<?php echo $d;?>"><br>
         <table>
           <tr>
             <td>Name:</td>
             <td><?php echo $a;?></td>
           </tr>
           <tr>
             <td>Address:</td>
             <td><?php echo $b;?></td>
           </tr>
           <tr>
             <td>Contact:</td>
             <td><?php echo $c;?></td>
           </tr>
   </table>

     <p class="pr"><button type="button" class="print" onclick="javascript:printLayer('div-id-name')">Print</button></p>



       </div>
     </body>
     </html>
