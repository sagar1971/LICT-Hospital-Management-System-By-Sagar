<?php
require('session.php');
?>
<?php
require('db.php');
?>

<?php

$connection_delete = mysqli_connect($ip, $user, $pass, $dbname);
$id = $_GET['pdel'];
if (!mysqli_connect_errno()){
  $visibility = 0;
  $update_query = "UPDATE patient SET `visible`= '{$visibility}' WHERE `id`='{$id}' ";
  if (mysqli_query($connection_delete,$update_query)) {
    echo "<script>window.location.href = 'allinone.php'</script>";
  }else{
    echo "ERROR : failed to Delete data"."<br>";
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection_delete);
?>
