<?php
require('session.php');
?>
<?php
require('db.php');
?>
<?php
if(isset($_POST['nsub'])){

  $name=$_POST['nnm'];
  $add=$_POST['nad'];
  $co=$_POST['ncon'];
  $visibility=1;

  $connection=mysqli_connect($ip,$user,$pass,$dbname);
      if(!mysqli_connect_errno()){
          echo "";
  $query="INSERT INTO nurse(`name`,`address`,`contact`,`visible`)
              VALUES('{$name}','{$add}','{$co}','{$visibility}')";

              if(mysqli_query($connection,$query)){
                echo "<script>alert('Your Data Successfully Inserted');</script>";
              }
               else{
                echo "Failed";
              }
            }else{
              die("ERROR:".mysqli_connect_error());
            }
          }
    mysqli_close($connection);
      header("location:allinone.php");

 ?>
