
<?php
require('session.php');
?>
<?php
require('db.php');
?>

<?php
if(isset($_POST['sub'])){

  $name=$_POST['dname'];
  $add=$_POST['dadd'];
  $co=$_POST['dcon'];
  $spe=$_POST['dspc'];
  $visibility=1;

  $connection=mysqli_connect($ip,$user,$pass,$dbname);
      if(!mysqli_connect_errno()){
          echo "";
  $query="INSERT INTO doctor(`name`,`address`,`contact`,`specialist`,`visible`)
              VALUES('{$name}','{$add}','{$co}','{$spe}','{$visibility}')";

              if(mysqli_query($connection,$query)){
                echo "<script>alert('Your Data Successfully Inserted');</script> ";
              }
               else{
                echo "  ";
              }
            }else{
              die("ERROR:".mysqli_connect_error());
            }
          }
  mysqli_close($connection);
  header("location:allinone.php");

 ?>
