<?php
require('session.php');
?>
<?php
require('db.php');
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="shortcut icon" type="image/x-icon" href="img/icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="js/jquery-3.1.0.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/clock.js"></script>
    <script src="js/all.js"></script>
    <link rel="stylesheet" href="css/clock.css">
    <link rel="stylesheet" href="css/all.css">
    <title>
        Hospital Management System
    </title>
  </head>
  <body>
    <!--This is header area-->
    <header id="hd">
      <img src="img/logo.png" id="logo">
      <img src="img/plus.png" id="plus">
      <h1>Hospital Management System</h1>
      <a href="logout.php"><img src="img/out.png" name="btn" id="btn"></a>
    </header>

    <!--This is main menus-->
    <div id="main">
      <ul>
        <li class="list"><a href ="#m1" class="menu">Dashboard</a></li>
        <li class="list"><a href ="#m2" class="menu">Appointments</a></li>
        <li class="list"><a href ="#m3" class="menu">Doctors</a></li>
        <li class="list"><a href ="#m4" class="menu">Patients</a></li>
        <li class="list"><a href ="#m5" class="menu">Nurses</a></li>
        <li class="list"><a href ="#m6" class="menu">Staffs</a></li>
        <li class="list"><a href ="#m7" class="menu">Blood bank</a></li>
        <li class="list"><a href ="#m8" class="menu">Accounts</a></li>
      </ul><br>
      <!--this is welcome and marquee area-->

      <div class="wlc">
        <img src="img/admin1.png" id="adm">
        <h4>Admin</h4>
      </div>
      <div class="wlc" id="mar">
        <marquee>Welcome to administrative area & now you can manage everything.......</marquee>
      </div><br>
      <!--this is navbar-->
      <div id="nav">
        <main>
          <!-- DAY OF THE WEEK -->
          <div class="days">

            <div class="day">
              <p class="sunday">sunday</p>
            </div>

            <div class="day">
              <p class="monday">monday</p>
            </div>

            <div class="day">
              <p class="tuesday">tuesday</p>
            </div>

            <div class="day">
              <p class="wednesday">wednesday</p>
            </div>

            <div class="day">
              <p class="thursday">thursday</p>
            </div>

            <div class="day">
              <p class="friday">friday</p>
            </div>

            <div class="day">
              <p class="saturday">saturday</p>
            </div>

          </div>
          <!-- CLOCK -->
          <div class="clock">
            <!-- HOUR -->
            <div class="numbers">
              <p class="hours"></p>
              <p class="placeholder">88</p>
            </div>

            <div class="colon">
              <p>:</p>
            </div>

            <!-- MINUTE -->
            <div class="numbers">
              <p class="minutes"></p>
              <p class="placeholder">88</p>
            </div>

            <div class="colon">
              <p>:</p>
            </div>

            <!-- SECOND -->
            <div class="numbers">
              <p class="seconds"></p>
              <p class="placeholder">88</p>
            </div>

            <!-- AM / PM -->
            <div class="am-pm">

              <!-- AM -->
              <div>
                <p class="am">am</p>
              </div>

              <!-- PM -->
              <div>
                <p class="pm">pm</p>
              </div>
            </div>

          </div><!-- END CLOCK -->

        </main>
        <h3 align="center" class="h3">Quick links</h3><hr>
        <ul>
          <li class="li">Admin profile</li>
          <li class="li">New appointment</li>
          <li class="li">Admit patient</li>
          <li class="li">New doctor</li>
          <li class="li">Settings</li>
        </ul><br>
        <h3>Social links:</h3>
        <ul>
          <li><a href="facebook.com"><img src="img/pin (4).png"  class="pin">Facebook</a></li>
          <li><a href="facebook.com"><img src="img/pin(6).png"  class="pin">Twitter</a></li>
          <li><a href="facebook.com"><img src="img/pin (5).png"  class="pin">Linkedin</a></li>
          <li><a href="facebook.com"><img src="img/pin (2).png"  class="pin">Skype</a></li>
          <li><a href="facebook.com"><img src="img/pin (1).png"  class="pin">pinterest</a></li>
          <li><a href="facebook.com"><img src="img/pin (3).png"  class="pin">Youtube</a></li>
        </ul>
      </div>
      <!--This is dashboard area-->
      <div id="m1">
        <div id="mm1">
        <div class="tab1">
          <a href="#"><b>Appointments</b></a>
          <br>
          <img src="img/app.jpg" class="icon">
        </div>
        <div class="tab1">
          <a href="#"><b>Doctors</b></a>

          <br>
          <img src="img/doc.jpg" class="icon">
        </div>
        <div class="tab1">
          <a href="#"><b>Patients</b></a>
          <br>
          <img src="img/pat.png" class="icon">
        </div><br>

        <div class="tab2">
          <a href="#"><b>Nurses</b></a>
          <br>
          <img src="img/nur.png" class="icon">
        </div>
        <div class="tab2">
          <a href="#"><b>Staffs</b></a>
          <br>
          <img src="img/sta.png" class="icon">
        </div>
        <div class="tab2">
          <a href="#"><b>Blood bank</b></a>
          <br>
          <img src="img/bl.png" class="icon">
        </div><br>

        <div class="tab3">
          <a href="#"><b>Accounts</b></a>
          <br>
          <img src="img/acc.png" class="icon">
        </div>
        <div class="tab3">
          <a href="#"><b>Reports</b></a>
          <br>
          <img src="img/rep.png" class="icon">
        </div>
        <div class="tab3">
          <a href="#"><b>Settings</b></a>
          <br>
          <img src="img/set.png" class="icon">
        </div>
      </div>
      </div>
      <!--This is appointments area-->
      <div id="m2">
        <p>Appointments</p>
        <ul>
          <li class="list1"><a href ="#t1" class="menu1">Appointment list</a></li>
          <li class="list1"><a href ="#t2" class="menu1">+Add new appointment</a></li>
          <li class="list1"><a href ="#t3" class="menu1">Completed appointments</a></li>
        </ul><br>
        <div id="t1">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM appointement where `visible`=1";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Age<div class='div'>Age</div></th>
                          <th class='head'>Gender<div class='div'>Gender</div></th>
                          <th class='head'>AppDoctor<div class='div'>AppDoctor</div></th>
                          <th class='head'>Specialist<div class='div'>Specialist</div></th>
                          <th class='head'>Symptoms<div class='div'>Symptoms</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr></hr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                  $sl=$sl+1;
                  $apid = $row['apid'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['apid']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['age']."</td>";
                  echo "<td class='head1'>".$row['gender']."</td>";
                  echo "<td class='head1'>".$row['apdoc']."</td>";
                  echo "<td class='head1'>".$row['specialist']."</td>";
                  echo "<td class='head1'>".$row['symptom']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'apv.php?apview=$apid' id='view'><button type='button' class='button'>View</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'upapp.php?upap=$apid' id='edit'><button type='button' class='button'>Edit</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'apdel.php?apdel=$apid' id='delete'><button type='button' class='button'>Delete</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div><br>
<!--this is form area..................................................-->
        <div id="t2">
          <form enctype="multipart/form-data" method="post" action="app.php" class="form">
            <h3 align=center>New Appointment !</h3><br>
            <img class="blah" src="#" alt="Image" />
            <table id="table1">
              <tr>
                <td class="td">
                    <input id="image-file" type="file" onchange="readURL(this);" name="img" value="image" />
                    <br>
                  </td>
                </tr>
                <tr>
                  <td class="td">
                      <label for="apname">Full name</label>
                    </td>
                    <td class="td">
                        <input type="text" name="apname" id="app" placeholder="Full name" required/><br>
                      </td>
                  </tr>
                    <tr>
                        <td class="td">
                          <label for="apadd">Address</label></td><td class="td">
                            <input type="text" name="apadd" id="apad" placeholder="Address" required/><br>
                          </td>
                      </tr>
                      <tr>
                        <td class="td">
                            <label for="apcon">Contact</label>
                          </td>
                        <td class="td">
                          <input type="text" name="apcon" id="apcon" placeholder="Contact" required/><br>
                        </td>
                      </tr>
                        <tr>
                            <td class="td">
                            <label for="apage">Age</label>
                          </td><td class="td">
                          <input type="text" name="apage" id="apage" placeholder="Current age" required/><br>
                        </td>
                      </tr>
                      <tr>
                        <td class="td">
                          <label for="apdoc">Appointed Doctor</label>
                        </td>
                        <td class="td">
                            <input type="text" name="apdoc" id="apdoc" placeholder="Doctor Name" required/>
                          </td>
                          <tr>
                          <td class="td">
                            <label for="smp">Symptom</label>
                          </td>
                            <td class="td">
                            <input type="text" name="smp" id="smp" placeholder="Symptom" required/>
                          </td>
                        </tr>
                        </tr>
                          <tr>
                            <td class="td">
                              <label for="apgen">Gender</label>
                            </td>
                            <td class="td" >
                              <label for="male">Male</label>
                              <input type="radio" name="apgen" id="male" value="Male">
                              <label for="female">Female</label>
                              <input type="radio" name="apgen" id="female" value="Female"><br>
                            </td>
                          </tr>
                          <tr>
                            <td class="td">
                              <label for="apspc">Specialist</label>
                            </td>
                            <td class="td">
                              <select name="apspc" id="apsp">
                                <option>Not selected</option>
                                <option>Medicine</option>
                                <option>Surgery</option>
                                <option>Orthopadic</option>
                                <option>Neurologist</option>
                                <option>Dermatologist</option>
                                <option>Cardiologist</option>
                                <option>Urology</option>
                                <option>NeuroSurgen</option>
                                <option>Gynecologist</option>
                              </td>

                              <td class="td">
                              <input type="submit" value="Save" name="sub" id="apsub">
                              <input type="reset" value="Clear" id="reset">
                            </td>
                          </tr>
            </table>
      </form>

        </div>
        <!--update php code starts from here.................................-->



<!--update php code ended herer.................................................-->
<!--this is modal area..................................-->

        <div id="t3">
          <?php

        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM appointement where `visible`=0";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Age<div class='div'>Age</div></th>
                          <th class='head'>Gender<div class='div'>Gender</div></th>
                          <th class='head'>AppDoctor<div class='div'>AppDoctor</div></th>
                          <th class='head'>Specialist<div class='div'>Specialist</div></th>
                          <th class='head'>Symptoms<div class='div'>Symptoms</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr></hr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                  $sl=$sl+1;
                  $rap = $row['apid'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['apid']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['age']."</td>";
                  echo "<td class='head1'>".$row['gender']."</td>";
                  echo "<td class='head1'>".$row['apdoc']."</td>";
                  echo "<td class='head1'>".$row['specialist']."</td>";
                  echo "<td class='head1'>".$row['symptom']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'rap.php?rap=$rap' id='delete'><button type='button' class='button'>Recover</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
      </div>
      <!--This is doctors area-->
      <div id="m3">
        <p>Doctors</p>
        <ul>
          <li class="list2"><a href ="#t4" class="menu2">Doctor list</a></li>
          <li class="list2"><a href ="#t5" class="menu2">+Add new doctor</a></li>
          <li class="list2"><a href ="#t6" class="menu2">Transfered doctors</a></li>
        </ul><br>
        <div id="t4">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM doctor where `visible`=1";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Specialist<div class='div'>Specialist</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                $did = $row['id'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['id']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['specialist']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'dv.php?dview=$did' id='view'><button type='button' class='button'>View</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'upd.php?upd=$did' id='edit'><button type='button' class='button'>Edit</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'ddel.php?ddel=$did' id='delete'><button type='button' class='button'>Delete</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
        <!--this is form area................-->
        <div id="t5">
          <form enctype="multipart/form-data" method="post" action="doc.php" class="form">
            <h3 align=center>Add New Doctors !</h3><br>
            <img class="blah" src="#" alt="Image" />
            <table id="table2">
              <tr>
                <td class="td">
                    <input id="image-file" type="file" onchange="readURL(this);" /><br>
                  </td>
                </tr>
                <tr>
                  <td class="td">
                      <label for="dname">Full name</label>
                    </td>
                    <td class="td">
                        <input type="text" name="dname" id="dnm" placeholder="Full name" required/><br>
                      </td>
                  </tr>
                    <tr>
                        <td class="td">
                          <label for="dadd">Address</label></td><td class="td">
                            <input type="text" name="dadd" id="dad" placeholder="Address" required/><br>
                          </td>
                      </tr>
                      <tr>
                        <td class="td">
                            <label for="dcon">Contact</label>
                          </td>
                        <td class="td">
                          <input type="text" name="dcon" id="dcon" placeholder="Contact" required/><br>
                        </td>
                      </tr>
                          <tr>
                            <td class="td">
                              <label for="dspc">Specialist</label>
                            </td>
                            <td class="td">
                              <select name="dspc" id="dsp">
                                <option>Not selected</option>
                                <option>Medicine</option>
                                <option>Surgery</option>
                                <option>Orthopadic</option>
                                <option>Neurologist</option>
                                <option>Dermatologist</option>
                                <option>Cardiologist</option>
                                <option>Urology</option>
                                <option>NeuroSurgen</option>
                                <option>Gynecologist</option>
                              </td>
                              <td class="td">
                              <input type="submit" value="Save" name="sub" id="dsub" onClick="updateForm();">
                              <input type="reset" value="Clear" id="reset">
                            </td>
                          </tr>
            </table>
      </form>



        </div>
        <div id="modal-wrapper2" class="modal">

          <div id="form_div">
            <form method="post" id="upap">
              <span onclick="document.getElementById('modal-wrapper2').style.display='none'" class="close" title="Close PopUp">
            </form>
          </div>

                </div>


        <div id="t6">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM doctor where `visible`=0";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Specialist<div class='div'>Specialist</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                $did = $row['id'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['id']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['specialist']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'rd.php?rd=$did' id='rec'><button type='button' class='button'>Recover</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
      </div>
      <!--This is patients area..................................-->
      <div id="m4">
        <p>Patients</p>
        <ul>
          <li class="list3"><a href ="#t7" class="menu3">Patien list</a></li>
          <li class="list3"><a href ="#t8" class="menu3">+Admit patient</a></li>
          <li class="list3"><a href ="#t9" class="menu3">Released patient</a></li>
        </ul><br>
        <div id="t7">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM patient where `visible`=1";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Age<div class='div'>Age</div></th>
                          <th class='head'>Gender<div class='div'>Gender</div></th>
                          <th class='head'>ReferDoctor<div class='div'>AppDoctor</div></th>
                          <th class='head'>Specialist<div class='div'>Specialist</div></th>
                          <th class='head'>Disease<div class='div'>Symptoms</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                $pid = $row['id'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['id']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['age']."</td>";
                  echo "<td class='head1'>".$row['gender']."</td>";
                  echo "<td class='head1'>".$row['refdooc']."</td>";
                  echo "<td class='head1'>".$row['specialist']."</td>";
                  echo "<td class='head1'>".$row['disease']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'pv.php?pview=$pid' id='view'><button type='button' class='button'>View</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'upp.php?upp=$pid' id='edit'><button type='button' class='button'>Edit</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'pdel.php?pdel=$pid' id='delete'><button type='button' class='button'>Delete</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
<!--this is form area........................____________________-->
        <div id="t8">
          <form enctype="multipart/form-data" method="post" action="pat.php" class="form">
            <h3 align=center>Admit Patient !</h3><br>
            <img class="blah" src="#" alt="Image" />
            <table id="table3">
              <tr>
                <td class="td">
                    <input id="image-file" type="file" onchange="readURL(this);" /><br>
                  </td>
                </tr>
                <tr>
                  <td class="td">
                      <label for="pname">Full name</label>
                    </td>
                    <td class="td">
                        <input type="text" name="pname" id="pnm" placeholder="Full name" required/><br>
                      </td>
                  </tr>
                    <tr>
                        <td class="td">
                          <label for="padd">Address</label></td><td class="td">
                            <input type="text" name="padd" id="pad" placeholder="Address" required/><br>
                          </td>
                      </tr>
                      <tr>
                        <td class="td">
                            <label for="pcon">Contact</label>
                          </td>
                        <td class="td">
                          <input type="text" name="pcon" id="pcon" placeholder="Contact" required/><br>
                        </td>
                      </tr>
                        <tr>
                            <td class="td">
                            <label for="page">Age</label>
                          </td><td class="td">
                          <input type="text" name="page" id="pge" placeholder="Current age" required/><br>
                        </td>
                      </tr>
                      <tr>
                        <td class="td">
                          <label for="prd">Refer Doctor</label>
                        </td>
                        <td class="td">
                            <input type="text" name="prd" id="prd" placeholder="Doctor Name" required/><br>
                          </td>
                        </tr>
                          <tr>
                            <td class="td">
                              <label for="pgen">Gender</label>
                            </td>
                            <td class="td" >
                              <label for="male">Male</label>
                              <input type="radio" name="pgen" id="male" value="Male">
                              <label for="female">Female</label>
                              <input type="radio" name="pgen" id="female" value="Female"><br>
                            </td>
                          </tr>
                          <tr>
                            <td class="td">
                              <label for="pspc">Specialist</label>
                            </td>
                            <td class="td">
                              <select name="pspc" id="psp">
                                <option>Not selected</option>
                                <option>Medicine</option>
                                <option>Surgery</option>
                                <option>Orthopadic</option>
                                <option>Neurologist</option>
                                <option>Dermatologist</option>
                                <option>Cardiologist</option>
                                <option>Urology</option>
                                <option>NeuroSurgen</option>
                                <option>Gynecologist</option>
                              </td>
                              <td class="td">
                              <input type="submit" value="Save" name="sub" id="psub" onClick="updateForm();">
                              <input type="reset" value="Clear" id="reset">
                            </td>
                          </tr>
            </table>
      </form>
        </div>
        <div id="t9">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM patient where `visible`=0";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Age<div class='div'>Age</div></th>
                          <th class='head'>Gender<div class='div'>Gender</div></th>
                          <th class='head'>ReferDoctor<div class='div'>AppDoctor</div></th>
                          <th class='head'>Specialist<div class='div'>Specialist</div></th>
                          <th class='head'>Disease<div class='div'>Symptoms</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                $pid = $row['id'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['id']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['age']."</td>";
                  echo "<td class='head1'>".$row['gender']."</td>";
                  echo "<td class='head1'>".$row['refdooc']."</td>";
                  echo "<td class='head1'>".$row['specialist']."</td>";
                  echo "<td class='head1'>".$row['disease']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'rp.php?rp=$pid' id='rec'><button type='button' class='button'>Recover</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
      </div>
      <!--This is nurses area-->
      <div id="m5">
        <p>Nurses</p>
        <ul>
          <li class="list4"><a href ="#t10" class="menu4">Nurse list</a></li>
          <li class="list4"><a href ="#t11" class="menu4">+Add nurse</a></li>
          <li class="list4"><a href ="#t12" class="menu4">Resigned nurses</a></li>
        </ul><br>
        <div id="t10">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM nurse where `visible`=1";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                $nid=$row['id'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['id']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'nv.php?nview=$nid' id='view'><button type='button' class='button'>View</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'upn.php?upn=$nid' id='edit'><button type='button' class='button'>Edit</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'ndel.php?ndel=$nid' id='delete'><button type='button' class='button'>Delete</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
        <!--this is form area..................-->
        <div id="t11">
          <form enctype="multipart/form-data" method="post" action="nur.php" class="form">
            <h3 align=center>Add Nurse !</h3><br>
            <img class="blah" src="#" alt="Image" />
            <table id="table4">
              <tr>
                <td class="td">
                    <input id="image-file" type="file" onchange="readURL(this);" /><br>
                  </td>
                </tr>
                <tr>
                  <td class="td">
                      <label for="nnm">Full name</label>
                    </td>
                    <td class="td">
                        <input type="text" name="nnm" id="nnm" placeholder="Full name" required/><br>
                      </td>
                  </tr>
                    <tr>
                        <td class="td">
                          <label for="nad">Address</label></td><td class="td">
                            <input type="text" name="nad" id="nad" placeholder="Address" required/><br>
                          </td>
                      </tr>
                      <tr>
                        <td class="td">
                            <label for="ncon">Contact</label>
                          </td>
                        <td class="td">
                          <input type="text" name="ncon" id="ncon" placeholder="Contact" required/><br>
                        </td>
                            <td class="td">
                              <input type="submit" value="Save" name="nsub" id="nsub" onClick="updateForm();">
                              <input type="reset" value="Clear" id="reset">
                            </td>
                          </tr>
            </table>
      </form>
        </div>
        <div id="t12">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM nurse where `visible`=0";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                $nid=$row['id'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['id']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'rn.php?rn=$nid' id='delete'><button type='button' class='button'>Recover</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
      </div>
      <!--This is staffs area-->
      <div id="m6">
        <p>Staffs</p>
        <ul>
          <li class="list5"><a href ="#t13" class="menu5">Staff list</a></li>
          <li class="list5"><a href ="#t14" class="menu5">+New staff</a></li>
          <li class="list5"><a href ="#t15" class="menu5">Deleted staffs</a></li>
        </ul><br>
        <div id="t13">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM staff where `visible`=1";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                $sid=$row['id'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['id']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'sv.php?sview=$sid' id='view'><button type='button' class='button'>View</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'ups.php?ups=$sid' id='edit'><button type='button' class='button'>Edit</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'sdel.php?sdel=$sid' id='delete'><button type='button' class='button'>Delete</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
<!--this is form area...........................-->
        <div id="t14">
          <form enctype="multipart/form-data" method="post" action="staff.php" class="form">
            <h3 align=center>New Stuff !</h3><br>
            <img class="blah" src="#" alt="Image" />
            <table id="table5">
              <tr>
                <td class="td">
                    <input id="image-file" type="file" onchange="readURL(this);" /><br>
                  </td>
                </tr>
                <tr>
                  <td class="td">
                      <label for="snm">Full name</label>
                    </td>
                    <td class="td">
                        <input type="text" name="snm" id="snm" placeholder="Full name" required/><br>
                      </td>
                  </tr>
                    <tr>
                        <td class="td">
                          <label for="sad">Address</label></td><td class="td">
                            <input type="text" name="sad" id="sad" placeholder="Address" required/><br>
                          </td>
                      </tr>
                      <tr>
                        <td class="td">
                            <label for="scon">Contact</label>
                          </td>
                        <td class="td">
                          <input type="text" name="scon" id="scon" placeholder="Contact" required/><br>
                        </td>
                          <td class="td">
                              <input type="submit" value="Save" name="ssub" id="ssub" onClick="updateForm();">
                              <input type="reset" value="Clear" id="reset">
                            </td>
                          </tr>
            </table>
      </form>
        </div>
        <div id="t15">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM staff where `visible`=0";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                $sid=$row['id'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['id']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'rs.php?rs=$sid' id='delete'><button type='button' class='button'>Recover</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
      </div>
      <!--This is laboratorist area-->
      <div id="m7">
        <p>Blood collections</p>
        <ul>
          <li class="list6"><a href ="#t30" class="menu6">Blood records</a></li>
          <li class="list6"><a href ="#t40" class="menu6">+Add blood</a></li>
        <!--  <li class="list6"><a href ="#t50" class="menu6">Blood stock</a></li>-->
          <li class="list6"><a href ="#t16" class="menu6">Laboratoris list</a></li>
          <li class="list6"><a href ="#t17" class="menu6">+New laboratorist</a></li>
          <li class="list6"><a href ="#t18" class="menu6">Quit laboratorist</a></li>
        </ul><br>
        <div id="t30">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM blood where `visible`=1";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Donor Name<div class='div'>Donor Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Blood_Group<div class='div'>Blood_Group</div></th>
                          <th class='head'>Quantity<div class='div'>Quantity</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                $bid=$row['id'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['id']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['bg']."</td>";
                  echo "<td class='head1'>".$row['quantity']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'bv.php?bview=$bid' id='view'><button type='button' class='button'>View</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'upb.php?upb=$bid' id='edit'><button type='button' class='button'>Edit</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'bdel.php?bdel=$bid' id='delete'><button type='button' class='button'>Delete</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
        <div id="t40">
          <form enctype="multipart/form-data" method="post" action="blood.php" class="form">
            <h3 align=center>New Donour !</h3><br>
            <img class="blah" src="#" alt="Image" />
            <table id="table5">
              <tr>
                <td class="td">
                    <input id="image-file" type="file" onchange="readURL(this);" /><br>
                  </td>
                </tr>
                <tr>
                  <td class="td">
                      <label for="bnm">Full name</label>
                    </td>
                    <td class="td">
                        <input type="text" name="bnm" id="bnm" placeholder="Full name" required/><br>
                      </td>
                  </tr>
                    <tr>
                        <td class="td">
                          <label for="bad">Address</label></td><td class="td">
                            <input type="text" name="bad" id="bad" placeholder="Address" required/><br>
                          </td>
                      </tr>
                      <tr>
                          <td class="td">
                            <label for="bgrp">Blood groups</label></td><td class="td">
                              <select name="bgrp" id="bgrp">
                                <option>Not selected</option>
                                <option>A(+)ve</option>
                                <option>B(+)ve</option>
                                <option>O(+)ve</option>
                                <option>AB(+)ve</option>
                                <option>A(-)ve</option>
                                <option>B(-)ve</option>
                                <option>O(-)ve</option>
                                <option>AB(-)ve</option><br>
                            </td>
                        </tr>
                        <tr>
                          <td class="td">
                              <label for="bqn">Quantity</label>
                            </td>
                            <td class="td">
                              <select name="bqn" id="bqn">
                                <option>Not selected</option>
                                <option>0.5 pound</option>
                                <option>1.0 pound</option>
                                <option>1.5 pound</option>
                                <option>2.0 pound</option>
                                <option>2.5 pound</option>
                                <option>3.0 pound</option>
                                <br>
                              </td>
                          </tr>
                      <tr>
                        <td class="td">
                            <label for="bcon">Contact</label>
                          </td>
                        <td class="td">
                          <input type="text" name="bcon" id="bcon" placeholder="Contact" required/><br>
                        </td>
                          <td class="td">
                              <input type="submit" value="Save" name="bsub" id="bsub">
                              <input type="reset" value="Clear" id="reset">
                            </td>
                          </tr>
            </table>
      </form>
        </div>
      <!--  <div id="t50">




          <?php
        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT SUM(as) AS Total  FROM stock where `bg`='A+'";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "";
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                  $row=$row['as'];

              }

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>



          <form  method="post" action="allstock.php">
            <table class="stock_tab">
              <tr class="tbhead">
                <th class="sth">Blood_Group</th>
                <th class="sth">Add_Blood</th>
                <th class="sth">Present_Blood</th>
                <th class="sth">Use_Blood</th>
                <th class="sth">Used_Blood</th>
              </tr>
              <tr class="trgrp">
                <td>A(+)ve</td>
                <td><input type="number" name="grpa" placeholder="Bags">
                  <input type="submit" value="Add" name="grpas"></td>
                  <td><?php echo $row; ?></td>
                  <td><input type="number" name="grpau" placeholder="Bags">
                    <input type="submit" value="Use" name="grpaus"></td>
                    <td>echo</td>
              </tr>
              <tr class="trgrp">
                <td>B(+)ve</td>
                <td><input type="number" name="grpb" placeholder="Bags">
                  <input type="submit" value="Add" name="grpbs"></td>
                  <td>echo</td>
                  <td><input type="number" name="grpbu" placeholder="Bags">
                    <input type="submit" value="Use" name="grpbus"></td>
                    <td>echo</td>
              </tr>
              <tr class="trgrp">
                <td>AB(+)ve</td>
                <td><input type="number" name="grpab" placeholder="Bags">
                  <input type="submit" value="Add" name="grpabs"></td>
                  <td>echo</td>
                  <td><input type="number" name="grpabu" placeholder="Bags">
                    <input type="submit" value="Use" name="grpabus"></td>
                    <td>echo</td>
              </tr>
              <tr class="trgrp">
                <td>O(+)ve</td>
                <td><input type="number" name="grpo" placeholder="Bags">
                  <input type="submit" value="Add" name="grpos"></td>
                  <td>echo</td>
                  <td><input type="number" name="grpou" placeholder="Bags">
                    <input type="submit" value="Use" name="grpous"></td>
                    <td>echo</td>
              </tr>

              <tr class="trgrp">
                <td>A(-)ve</td>
                <td><input type="number" name="grpan" placeholder="Bags">
                  <input type="submit" value="Add" name="grpans"></td>
                  <td>echo</td>
                  <td><input type="number" name="grpanu" placeholder="Bags">
                    <input type="submit" value="Use" name="grpanus"></td>
                    <td>echo</td>
              </tr>
              <tr class="trgrp">
                <td>B(+)ve</td>
                <td><input type="number" name="grpbn" placeholder="Bags">
                  <input type="submit" value="Add" name="grpbns"></td>
                  <td>echo</td>
                  <td><input type="number" name="grpbnu" placeholder="Bags">
                    <input type="submit" value="Use" name="grpbnus"></td>
                    <td>echo</td>
              </tr>
              <tr class="trgrp">
                <td>AB(+)ve</td>
                <td><input type="number" name="grpabn" placeholder="Bags">
                  <input type="submit" value="Add" name="grpabns"></td>
                  <td>echo</td>
                  <td><input type="number" name="grpabnu" placeholder="Bags">
                    <input type="submit" value="Use" name="grpabnus"></td>
                    <td>echo</td>
              </tr>
              <tr class="trgrp">
                <td>O(+)ve</td>
                <td><input type="number" name="grpon" placeholder="Bags">
                  <input type="submit" value="Add" name="grpons"></td>
                  <td>echo</td>
                  <td><input type="number" name="grponu" placeholder="Bags">
                    <input type="submit" value="Use" name="grponus"></td>
                    <td>echo</td>
              </tr>
            </table>
      </form>
    </div>-->
        <div id="t16">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM lab where `visible`=1";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                $lid=$row['id'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['id']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'lv.php?lview=$lid' id='view'><button type='button' class='button'>View</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'upl.php?upl=$lid' id='edit'><button type='button' class='button'>Edit</button></a>"."</td>";
                  echo "<td class='head1'>"."<a href = 'ldel.php?ldel=$lid' id='delete'><button type='button' class='button'>Delete</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
<!--this is form area..............................-->
        <div id="t17">
          <form enctype="multipart/form-data" method="post" action="lab.php" class="form">
            <h3 align=center>Add New !</h3><br>
            <img class="blah" src="#" alt="Image" />
            <table id="table6">
              <tr>
                <td class="td">
                    <input id="image-file" type="file" onchange="readURL(this);" /><br>
                  </td>
                </tr>
                <tr>
                  <td class="td">
                      <label for="lnm">Full name</label>
                    </td>
                    <td class="td">
                        <input type="text" name="lnm" id="lnm" placeholder="Full name" required/><br>
                      </td>
                  </tr>
                    <tr>
                        <td class="td">
                          <label for="lad">Address</label></td><td class="td">
                            <input type="text" name="lad" id="lad" placeholder="Address" required/><br>
                          </td>
                      </tr>
                      <tr>
                        <td class="td">
                            <label for="lcon">Contact</label>
                          </td>
                        <td class="td">
                          <input type="text" name="lcon" id="lcon" placeholder="Contact" required/><br>
                        </td>
                              <td class="td">
                              <input type="submit" value="Save" name="lsub" id="lsub" onClick="updateForm();">
                              <input type="reset" value="Clear" id="reset">
                            </td>
                          </tr>
            </table>
      </form>
        </div>
        <div id="t18">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM lab where `visible`=0";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Address<div class='div'>Address</div></th>
                          <th class='head'>Contact<div class='div'>Contact</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                          <th class='head'>Action<div class='div'>Action</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                $lid=$row['id'];
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['id']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['address']."</td>";
                  echo "<td class='head1'>".$row['contact']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "<td class='head1'>"."<a href = 'rl.php?rl=$lid' id='delete'><button type='button' class='button'>Recover</button></a>"."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
      </div>
      <!--This is accounts area-->
      <div id="m8">
        <p>Accounts</p>
        <ul>
          <li class="list7"><a href ="#t19" class="menu7">App_Earnings</a></li>
          <li class="list7"><a href ="#t20" class="menu7">Pat_Earnings</a></li>

        </ul><br>
        <div id="t19">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM appointement where `fees`=500";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Paid<div class='div'>Paid</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['apid']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['fees']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
        <div id="t20">
          <?php


        $connection_read=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
          $query="SELECT * FROM patient where `fees`=1080";
          $result=mysqli_query($connection_read,$query);

          if($result){
            echo "<form>
                <section class=''>
                  <div class='container'>
                    <table class='scroll'>
                      <thead>
                        <tr class='header'>
                          <th class='head'>Serial<div class='div'>Serial</div></th>
                          <th class='head'>ID<div class='div'>ID</div></th>
                          <th class='head'>Name<div class='div'>Name</div></th>
                          <th class='head'>Paid<div class='div'>Paid</div></th>
                          <th class='head'>Time<div class='div'>Time</div></th>
                        </tr>
                      </thead>";
                      $sl=0;
              while($row=mysqli_fetch_array($result, MYSQLI_BOTH)){
                $sl=$sl+1;
                  echo "<tbody>";
                  echo "<tr class='tr'>";
                  echo "<td class='head1'>".$sl."</td>";
                  echo "<td class='head1'>".$row['id']."</td>";
                  echo "<td class='head1'>".$row['name']."</td>";
                  echo "<td class='head1'>".$row['fees']."</td>";
                  echo "<td class='head1'>".$row['time']."</td>";
                  echo "</tr>";
                  echo "</tbody>";
              }
                  echo "</table>";
                  echo "</div>";
                  echo "</section>";
                  echo "</form>";

          }
        }else{
          die("ERROR:".mysqli_connect_error());
        }
        mysqli_close($connection_read);


      ?>
        </div>
<!--this is form area......................-->


      </div>
      <!--This is reports area-->

    </div>

    <!--this is footer area...................................-->
    <footer>
    <div class="foo">
      About Us<br>
      We provide best treatment to our patients.And assure them to their best protection & comfortness.
        Always try to behave polite with them.
    </div>
    <div class="foo">
      Contact Us<br>
      Newtown_5no. street no.#0849 Word no.09
        house:S-14 under Sadar Dinajpur(Dinajpur)
        Bangladesh.<br><br><br>

          Copyright 2017-2018 by Md. Sultan Shahid Sagar
    </div>
    <div class="foo">
      Developers<br>
      By Md.Sultan Shahid Sagar & Md. Reza Hossain
        Institute:BDJobs(LICT)project.
        Under Dinajpur district(Bangladesh)
        Mobile:+8801759325153
        Mobile:+8801767513940
          <img src="img/reza.png" class="fimg"><img src="img/admin1.png" class="fimg">
    </div>
    </footer>

  </body>
</html>
