
<?php
require('db.php');
?>


<?php
session_start();

$user_check = $_SESSION['login_user'];
$connection_read = mysqli_connect($ip, $user,$pass, $dbname);
$ses_sql = mysqli_query($connection_read,"SELECT `user` FROM login_system WHERE `user` = '{$user_check}' ");
$row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
$login_session = $row['user'];
if(!isset($_SESSION['login_user'])){
  header("location:index.php");
}

?>
