<?php
require('session.php');
?>
<?php
require('db.php');
?>


<?php
if(isset($_POST['sub'])){

  $name=$_POST['pname'];
  $add=$_POST['padd'];
  $co=$_POST['pcon'];
  $spe=$_POST['pspc'];
  $age=$_POST['page'];
  $apdoc=$_POST['prd'];
  $gen=$_POST['pgen'];
  $fee=1080;
  $visibility=1;

  $connection=mysqli_connect($ip,$user,$pass,$dbname);
      if(!mysqli_connect_errno()){
          echo "";
  $query="INSERT INTO patient(`name`,`address`,`contact`,`specialist`,`gender`,`refdooc`,`age`,`visible`,`fees`)
              VALUES('{$name}','{$add}','{$co}','{$spe}','{$gen}','{$apdoc}','{$age}','{$visibility}','$fee')";

              if(mysqli_query($connection,$query)){
                echo "<script>alert('Your Data Successfully Inserted');</script>";
              }
               else{
                echo "Failed";
              }
            }else{
              die("ERROR:".mysqli_connect_error());
            }
          }
  mysqli_close($connection);
  header("location:allinone.php");
 ?>
