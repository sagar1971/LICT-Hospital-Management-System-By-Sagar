<?php
require('session.php');
?>
<?php
require('db.php');
?>


<?php
if(isset($_POST['bsub'])){
  $name=$_POST['bnm'];
  $add=$_POST['bad'];
  $co=$_POST['bcon'];
  $bg=$_POST['bgrp'];
  $qnt=$_POST['bqn'];
  $visibility=1;

  $connection=mysqli_connect($ip,$user,$pass,$dbname);
      if(!mysqli_connect_errno()){
          echo "";
  $query="INSERT INTO blood(`name`,`address`,`contact`,`visible`,`bg`,`quantity`)
              VALUES('{$name}','{$add}','{$co}','{$visibility}','{$bg}','{$qnt}')";

              if(mysqli_query($connection,$query)){
                echo "<script>alert('Your Data Successfully Inserted');</script>";
              }
               else{
                echo "Failed";
              }
            }else{
              die("ERROR:".mysqli_connect_error());
            }
          }
    mysqli_close($connection);
      header("location:allinone.php");

 ?>
