<?php
require('session.php');
?>
<?php
require('db.php');
?>


<?php

      $connection_read = mysqli_connect($ip, $user, $pass, $dbname);
      $id = '';
      if( isset( $_GET['upp'])) {
        $id = $_GET['upp'];
      }
      if (!mysqli_connect_errno()){
        $query = "SELECT * FROM patient WHERE `id`='{$id}'";
        $result = mysqli_query($connection_read,$query);
        if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
          $a=$row['name'];
          $b=$row['address'];
          $c=$row['contact'];
          $d=$row['age'];
          $e=$row['refdooc'];
          $f=$row['gender'];
          $g=$row['specialist'];



        }
      }else{
        echo "ERROR : Database connection failed !"."<br>";
      }
      mysqli_close($connection_read);
      ?>

      <?php
      if (isset($_POST['uapsubmit'])) {
        $na = $_POST['uapnm'];
        $ad = $_POST['uapad'];
        $co = $_POST['uapcon'];
        $ag = $_POST['uapag'];
        $do = $_POST['uapdoc'];
        $ge = $_POST['uapgen'];
        $sp = $_POST['uapspc'];

        $connection_read= mysqli_connect($ip, $user, $pass, $dbname);
        if (!mysqli_connect_errno()) {
          $visibility = 1;
          $query = "UPDATE patient SET `name`='{$na}',`address`='{$ad}',`contact`='{$co}'
          ,`age`='{$ag}',`apdoc`='{$do}',`gender`='{$ge}',`specialist`='{$sp}'WHERE `id`='{$id}' ";
          if(mysqli_query($connection_read, $query)){
            header("location:allinone.php");
          }else{
            echo "<script>alert('ERROR : Database Insert Failed because login name exists');</script>";
          }
        }else{
          die("ERROR : ".mysqli_connect_error());
        }
        mysqli_close($connection_read);
      }
      ?>
      <html>
      <head>
        <link rel="shortcut icon" type="image/x-icon" href="img/icon.png">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="js/jquery-3.1.0.min.js"></script>
        <script src="js/jquery-ui.js"></script>
        <script src="js/all.js"></script>
        <style media="screen">
        body{
          background-image: url(img/back.PNG);
          background-repeat: no-repeat;
          background-size: 100%;
        }
        #form_div{
          width: 60%;
          height: 500px;
          background-color: white;
          border: 8px solid #56D4E3;
          margin: auto;
          border-top: 30px solid #56D4E3;


        }

        .upap{
          padding-left: 80px;
          font-size: 20px;
        }
        .uiap{
          float: right;
          margin-right: 250px;
          width: 250px;
          border: none;
          border-bottom: 1px solid gray;
        }
        .uaps{

          float: right;
          margin-right: 250px;
          width: 180px;
          height: 30px;
          background-color: rgba(36, 184, 216, 0.72);

        }
        .uapc{
          float: right;
          width: 80px;
          height: 30px;
          background-color: #BABA7A;
        }
        .uiapr{
          margin-left: 130px;
        }
        span{
          float: right;
          margin-top: -30px;
          font-size: 24px;
          font-weight: bolder;

        }
        </style>
      </head>
      <body>



        <div id="form_div">
          <a href="allinone.php">  <span  class="close">
   &times;
  </span></a>
          <form method="post" id="upap">
            <h3 align="center">Update Data</h3><br>
            <label for="uapnm" class="upap">Full Name  </label>
            <input type="text" name="uapnm" value="<?php echo $a; ?>" placeholder="Enter full name" class="uiap"><br>
            <label for="uapad" class="upap">Address</label>
            <input type="text" name="uapad" value="<?php echo $b; ?>" placeholder="Full address" class="uiap"><br>
            <label for="uapcon" class="upap">Contact</label>
            <input type="text" name="uapcon" value="<?php echo $c; ?>" placeholder="Contact" class="uiap"><br>
            <label for="uapag" class="upap">Age</label>
            <input type="text" name="uapag" value="<?php echo $d; ?>" placeholder="Current age" class="uiap"><br>
            <label for="uapdoc" class="upap">Appointed Docctor</label>
            <input type="text" name="uapdoc" value="<?php echo $e; ?>" placeholder="Doctor name" class="uiap"><br>
            <label for="uapgen" class="upap">Gender</label>
            <input type="radio" name="uapgen" value="<?php echo $f; ?>" class="uiapr">Male<input type="radio" name="uapgen" value="<?php echo $f; ?>" class="uiapr">Female<br>
            <label for="apspc" class="upap">Specialist</label>
            <select name="uapspc" id="uapsp" class="uiap" value="<?php echo $g; ?>">
              <option>Not selected</option>
              <option>Medicine</option>
              <option>Surgery</option>
              <option>Orthopadic</option>
              <option>Neurologist</option>
              <option>Cardiologist</option>
              <option>Urology</option>
              <option>NeuroSurgen</option>
              <option>Gynecologist</option>
            <input type="submit" name="uapsubmit" value="Update Data" class="uaps">
            <input type="reset" name="reset" value="Clear" class="uapc">
            <p></p>
          </form>
        </div>
        </body>
        </html>
