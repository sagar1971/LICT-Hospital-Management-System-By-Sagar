
<?php
require('db.php');
?>
<?php
session_start();
if(isset($_POST['sub'])) {

  $visibility = 1;
  $connection_read = mysqli_connect($ip, $user,$pass, $dbname);
  $myusername = mysqli_real_escape_string($connection_read,$_POST['username']);
  $mypassword = mysqli_real_escape_string($connection_read,$_POST['password']);
  $sql = "SELECT `id` FROM login_system WHERE `user`= '{$myusername}' and `password` = '{$mypassword}' AND
  `visible` = '{$visibility}'";
  $result = mysqli_query($connection_read,$sql);
  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
  $active = $row['active'];
  $count = mysqli_num_rows($result);
  // If result matched $myusername and $mypassword, table row must be 1 row
  if($count == 1) {
    $_SESSION['login_user'] = $myusername;
    header("location: allinone.php");
  }else {
    echo "<script>alert('Your Login Name or Password is invalid');</script>";
  }
}
?>


<html>
<head>
  <title>
    Hospital Management System
  </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" type="image/x-icon" href="img/icon.png">
  <link rel="stylesheet" href="css/index.css">
</head>
<body>
  <header>
    <img src="img/logo.png" alt="logo" id="logoimg">
    <h1>
      <img src="img/plus.png" id="plus">
    Hospital Management System
  </h1>

  </header>
  <img src="img/side.jpg" alt="image" id="sideimg">
  <div id="box">
    <b>Admin Login</b>
    <form id="form" method="post">
      <label for="username">Username:</label>
      <input type="email" name="username" id="userid" placeholder="Username" required/><br>
      <label for="password">Password :</label>
      <input type="password" name="password" id="pass" placeholder="Password" required/><br>
      <input type="submit" value="Login" name="sub" class="btn1">
      <input type="reset" value="Clear" class="btn2">
    </form>
  </div>

  <div id="sug">
    Username:sagar@user.com
    Password:admin
  </div>
  <footer>
  <div class="foo">About Us
    <p>We provide best treatment to our patients.And assure them to their best protection & comfortness.
      Always try to behave polite with them.</p>
  </div>
  <div class="foo">Contact Us
    <p>Newtown_5no. street no.#0849 Word no.09
      house:S-14 under Sadar Dinajpur(Dinajpur)
      Bangladesh.<br><br><br>
        Copyright 2017-2018 by Md. Sultan Shahid Sagar
  </div>
  <div class="foo">Developers
    <p>By Md.Sultan Shahid Sagar & Md. Reza Hossain
      Institute:BDJobs(LICT)project.
      Under Dinajpur district(Bangladesh)
      Mobile:+8801759325153
      Mobile:+8801767513940
  </div>
  </footer>
</body>
</html>
