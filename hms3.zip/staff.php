<?php
require('session.php');
?>
<?php
require('db.php');
?>


<?php
if(isset($_POST['ssub'])){

  $name=$_POST['snm'];
  $add=$_POST['sad'];
  $co=$_POST['scon'];
  $visibility=1;

  $connection=mysqli_connect($ip,$user,$pass,$dbname);
      if(!mysqli_connect_errno()){
          echo "";
  $query="INSERT INTO staff(`name`,`address`,`contact`,`visible`)
              VALUES('{$name}','{$add}','{$co}','{$visibility}')";

              if(mysqli_query($connection,$query)){
                echo "<script>alert('Your Data Successfully Inserted');</script>";
              }
               else{
                echo "Failed";
              }
            }else{
              die("ERROR:".mysqli_connect_error());
            }
          }
    mysqli_close($connection);
    header("location:allinone.php");

 ?>
