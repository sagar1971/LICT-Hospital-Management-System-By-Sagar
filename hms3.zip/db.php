<?php
$ip='localhost';
$user='root';
$pass='';
$dbname='hms2';
?>
