<?php
require('session.php');

require('db.php');

if(isset($_POST['grpas'])){

  $name="A+";
  $add=$_POST['grpa'];
  $visibility=1;

  $connection=mysqli_connect($ip,$user,$pass,$dbname);
      if(!mysqli_connect_errno()){
          echo "";
  $query="INSERT INTO stock(`bg`,`as`,`visible`)
              VALUES('{$name}','{$add}','{$visibility}')";

              if(mysqli_query($connection,$query)){
                echo "<script>window.location.href = 'allinone.php'</script>";
              }
               else{
                echo "Failed";
              }
            }else{
              die("ERROR:".mysqli_connect_error());
            }
          }
    mysqli_close($connection);
 ?>

 <?php
 require('session.php');

 require('db.php');

 if(isset($_POST['grpaus'])){

   $name="A+";
   $add=$_POST['grpau'];
   $visibility=1;

   $connection=mysqli_connect($ip,$user,$pass,$dbname);
       if(!mysqli_connect_errno()){
           echo "";
   $query="INSERT INTO stock(`bg`,`ua`,`visible`)
               VALUES('{$name}','{$add}','{$visibility}')";

               if(mysqli_query($connection,$query)){
                 echo "<script>window.location.href = 'allinone.php'</script>";
               }
                else{
                 echo "Failed";
               }
             }else{
               die("ERROR:".mysqli_connect_error());
             }
           }
     mysqli_close($connection);
  ?>



  <?php
  require('session.php');

  require('db.php');

  if(isset($_POST['grpbs'])){

    $name="B+";
    $add=$_POST['grpb'];
    $visibility=1;

    $connection=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
            echo "";
    $query="INSERT INTO stock(`bg`,`as`,`visible`)
                VALUES('{$name}','{$add}','{$visibility}')";

                if(mysqli_query($connection,$query)){
                  echo "<script>window.location.href = 'allinone.php'</script>";
                }
                 else{
                  echo "Failed";
                }
              }else{
                die("ERROR:".mysqli_connect_error());
              }
            }
      mysqli_close($connection);
   ?>


   <?php
   require('session.php');

   require('db.php');

   if(isset($_POST['grpbus'])){

     $name="B+";
     $add=$_POST['grpbu'];
     $visibility=1;

     $connection=mysqli_connect($ip,$user,$pass,$dbname);
         if(!mysqli_connect_errno()){
             echo "";
     $query="INSERT INTO stock(`bg`,`as`,`visible`)
                 VALUES('{$name}','{$add}','{$visibility}')";

                 if(mysqli_query($connection,$query)){
                   echo "<script>window.location.href = 'allinone.php'</script>";
                 }
                  else{
                   echo "Failed";
                 }
               }else{
                 die("ERROR:".mysqli_connect_error());
               }
             }
       mysqli_close($connection);
    ?>


    <?php
    require('session.php');

    require('db.php');

    if(isset($_POST['grpabs'])){

      $name="AB+";
      $add=$_POST['grpab'];
      $visibility=1;

      $connection=mysqli_connect($ip,$user,$pass,$dbname);
          if(!mysqli_connect_errno()){
              echo "";
      $query="INSERT INTO stock(`bg`,`as`,`visible`)
                  VALUES('{$name}','{$add}','{$visibility}')";

                  if(mysqli_query($connection,$query)){
                    echo "<script>window.location.href = 'allinone.php'</script>";
                  }
                   else{
                    echo "Failed";
                  }
                }else{
                  die("ERROR:".mysqli_connect_error());
                }
              }
        mysqli_close($connection);
     ?>

     <?php
     require('session.php');

     require('db.php');

     if(isset($_POST['grpabus'])){

       $name="AB+";
       $add=$_POST['grpabu'];
       $visibility=1;

       $connection=mysqli_connect($ip,$user,$pass,$dbname);
           if(!mysqli_connect_errno()){
               echo "";
       $query="INSERT INTO stock(`bg`,`as`,`visible`)
                   VALUES('{$name}','{$add}','{$visibility}')";

                   if(mysqli_query($connection,$query)){
                     echo "<script>window.location.href = 'allinone.php'</script>";
                   }
                    else{
                     echo "Failed";
                   }
                 }else{
                   die("ERROR:".mysqli_connect_error());
                 }
               }
         mysqli_close($connection);
      ?>
      <?php
      require('session.php');

      require('db.php');

      if(isset($_POST['grpos'])){

        $name="O+";
        $add=$_POST['grpo'];
        $visibility=1;

        $connection=mysqli_connect($ip,$user,$pass,$dbname);
            if(!mysqli_connect_errno()){
                echo "";
        $query="INSERT INTO stock(`bg`,`as`,`visible`)
                    VALUES('{$name}','{$add}','{$visibility}')";

                    if(mysqli_query($connection,$query)){
                      echo "<script>window.location.href = 'allinone.php'</script>";
                    }
                     else{
                      echo "Failed";
                    }
                  }else{
                    die("ERROR:".mysqli_connect_error());
                  }
                }
          mysqli_close($connection);
       ?>
       <?php
       require('session.php');

       require('db.php');

       if(isset($_POST['grpous'])){

         $name="O+";
         $add=$_POST['grpou'];
         $visibility=1;

         $connection=mysqli_connect($ip,$user,$pass,$dbname);
             if(!mysqli_connect_errno()){
                 echo "";
         $query="INSERT INTO stock(`bg`,`as`,`visible`)
                     VALUES('{$name}','{$add}','{$visibility}')";

                     if(mysqli_query($connection,$query)){
                       echo "<script>window.location.href = 'allinone.php'</script>";
                     }
                      else{
                       echo "Failed";
                     }
                   }else{
                     die("ERROR:".mysqli_connect_error());
                   }
                 }
           mysqli_close($connection);
        ?>

  <!--/////////////////////////////////////////////////////////////////////////////////-->


  <?php
  require('session.php');

  require('db.php');

  if(isset($_POST['grpans'])){

    $name="A-";
    $add=$_POST['grpan'];
    $visibility=1;

    $connection=mysqli_connect($ip,$user,$pass,$dbname);
        if(!mysqli_connect_errno()){
            echo "";
    $query="INSERT INTO stock(`bg`,`as`,`visible`)
                VALUES('{$name}','{$add}','{$visibility}')";

                if(mysqli_query($connection,$query)){
                  echo "<script>window.location.href = 'allinone.php'</script>";
                }
                 else{
                  echo "Failed";
                }
              }else{
                die("ERROR:".mysqli_connect_error());
              }
            }
      mysqli_close($connection);
   ?>

   <?php
   require('session.php');

   require('db.php');

   if(isset($_POST['grpanus'])){

     $name="A-";
     $add=$_POST['grpanu'];
     $visibility=1;

     $connection=mysqli_connect($ip,$user,$pass,$dbname);
         if(!mysqli_connect_errno()){
             echo "";
     $query="INSERT INTO stock(`bg`,`ua`,`visible`)
                 VALUES('{$name}','{$add}','{$visibility}')";

                 if(mysqli_query($connection,$query)){
                   echo "<script>window.location.href = 'allinone.php'</script>";
                 }
                  else{
                   echo "Failed";
                 }
               }else{
                 die("ERROR:".mysqli_connect_error());
               }
             }
       mysqli_close($connection);
    ?>



    <?php
    require('session.php');

    require('db.php');

    if(isset($_POST['grpbns'])){

      $name="B-";
      $add=$_POST['grpbn'];
      $visibility=1;

      $connection=mysqli_connect($ip,$user,$pass,$dbname);
          if(!mysqli_connect_errno()){
              echo "";
      $query="INSERT INTO stock(`bg`,`as`,`visible`)
                  VALUES('{$name}','{$add}','{$visibility}')";

                  if(mysqli_query($connection,$query)){
                    echo "<script>window.location.href = 'allinone.php'</script>";
                  }
                   else{
                    echo "Failed";
                  }
                }else{
                  die("ERROR:".mysqli_connect_error());
                }
              }
        mysqli_close($connection);
     ?>


     <?php
     require('session.php');

     require('db.php');

     if(isset($_POST['grpbnus'])){

       $name="B-";
       $add=$_POST['grpbnu'];
       $visibility=1;

       $connection=mysqli_connect($ip,$user,$pass,$dbname);
           if(!mysqli_connect_errno()){
               echo "";
       $query="INSERT INTO stock(`bg`,`as`,`visible`)
                   VALUES('{$name}','{$add}','{$visibility}')";

                   if(mysqli_query($connection,$query)){
                     echo "<script>window.location.href = 'allinone.php'</script>";
                   }
                    else{
                     echo "Failed";
                   }
                 }else{
                   die("ERROR:".mysqli_connect_error());
                 }
               }
         mysqli_close($connection);
      ?>


      <?php
      require('session.php');

      require('db.php');

      if(isset($_POST['grpabns'])){

        $name="AB-";
        $add=$_POST['grpabn'];
        $visibility=1;

        $connection=mysqli_connect($ip,$user,$pass,$dbname);
            if(!mysqli_connect_errno()){
                echo "";
        $query="INSERT INTO stock(`bg`,`as`,`visible`)
                    VALUES('{$name}','{$add}','{$visibility}')";

                    if(mysqli_query($connection,$query)){
                      echo "<script>window.location.href = 'allinone.php'</script>";
                    }
                     else{
                      echo "Failed";
                    }
                  }else{
                    die("ERROR:".mysqli_connect_error());
                  }
                }
          mysqli_close($connection);
       ?>

       <?php
       require('session.php');

       require('db.php');

       if(isset($_POST['grpabnus'])){

         $name="AB-";
         $add=$_POST['grpabnu'];
         $visibility=1;

         $connection=mysqli_connect($ip,$user,$pass,$dbname);
             if(!mysqli_connect_errno()){
                 echo "";
         $query="INSERT INTO stock(`bg`,`as`,`visible`)
                     VALUES('{$name}','{$add}','{$visibility}')";

                     if(mysqli_query($connection,$query)){
                       echo "<script>window.location.href = 'allinone.php'</script>";
                     }
                      else{
                       echo "Failed";
                     }
                   }else{
                     die("ERROR:".mysqli_connect_error());
                   }
                 }
           mysqli_close($connection);
        ?>
        <?php
        require('session.php');

        require('db.php');

        if(isset($_POST['grpons'])){

          $name="O-";
          $add=$_POST['grpon'];
          $visibility=1;

          $connection=mysqli_connect($ip,$user,$pass,$dbname);
              if(!mysqli_connect_errno()){
                  echo "";
          $query="INSERT INTO stock(`bg`,`as`,`visible`)
                      VALUES('{$name}','{$add}','{$visibility}')";

                      if(mysqli_query($connection,$query)){
                        echo "<script>window.location.href = 'allinone.php'</script>";
                      }
                       else{
                        echo "Failed";
                      }
                    }else{
                      die("ERROR:".mysqli_connect_error());
                    }
                  }
            mysqli_close($connection);
         ?>
         <?php
         require('session.php');

         require('db.php');

         if(isset($_POST['grponus'])){

           $name="O-";
           $add=$_POST['grponu'];
           $visibility=1;

           $connection=mysqli_connect($ip,$user,$pass,$dbname);
               if(!mysqli_connect_errno()){
                   echo "";
           $query="INSERT INTO stock(`bg`,`as`,`visible`)
                       VALUES('{$name}','{$add}','{$visibility}')";

                       if(mysqli_query($connection,$query)){
                         echo "<script>window.location.href = 'allinone.php'</script>";
                       }
                        else{
                         echo "Failed";
                       }
                     }else{
                       die("ERROR:".mysqli_connect_error());
                     }
                   }
             mysqli_close($connection);
          ?>
